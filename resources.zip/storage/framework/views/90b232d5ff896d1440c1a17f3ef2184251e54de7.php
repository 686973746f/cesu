

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <div>
                        List of Patients
                    </div>
                    <div>
                        <a href="<?php echo e(route('records.create')); ?>" class="btn btn-success">Add Patient</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-<?php echo e(session('statustype')); ?>" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <hr>
                <?php endif; ?>
                <table class="table table-bordered" id="table_id">
                    <thead>
                        <tr class="text-center">
                            <th>Name</th>
                            <th>Birthdate</th>
                            <th>Age/Gender</th>
                            <th>Civil Status</th>
                            <th>Mobile</th>
                            <th>Philhealth</th>
                            <th>Occupation</th>
                            <th>Created By</th>
                            <th>Created At</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($record->user->brgy_id == auth()->user()->brgy_id || is_null(auth()->user()->brgy_id)): ?>
                                <tr>
                                    <td style="vertical-align: middle"><?php echo e($record->lname.", ".$record->fname." ".$record->mname); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e(date("m/d/Y", strtotime($record->bdate))); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e($record->getAge()); ?> / <?php echo e($record->gender); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e($record->cs); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e($record->mobile); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e((!is_null($record->philhealth)) ? $record->philhealth : "N/A"); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e((!is_null($record->occupation)) ? $record->occupation : "N/A"); ?></td>
                                    <td style="vertical-align: middle"><?php echo e($record->user->name); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><?php echo e(date('m/d/Y h:i A', strtotime($record->created_at))); ?></td>
                                    <td style="vertical-align: middle" class="text-center"><a href="records/<?php echo e($record->id); ?>/edit" class="btn btn-primary">Edit</a></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('#table_id').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cesu\resources\views/records.blade.php ENDPATH**/ ?>