

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="/forms/<?php echo e($records->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card">
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <div class="alert alert-info" role="alert">
                        All fields marked with an asterisk (<span class="text-danger font-weight-bold">*</span>) are required.
                    </div>
                    <hr>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr>
                    <?php endif; ?>
    
                    <div class="form-group">
                        <label for=""><span class="text-danger font-weight-bold">*</span>Selected CIF Information to Edit</label>
                        <input type="text" class="form-control" value="<?php echo e($records->records->lname); ?>, <?php echo e($records->records->fname); ?> <?php echo e($records->records->mname); ?> | <?php echo e($records->records->gender); ?> | <?php echo e(date("m/d/Y", strtotime($records->records->bdate))); ?>" disabled>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="drunit"><span class="text-danger font-weight-bold">*</span>Disease Reporting Unit</label>
                                <select class="form-control" name="drunit" id="drunit" required>
                                    <option value="" disabled <?php echo e((is_null(old('drunit', $records->drunit))) ? 'selected' : ''); ?>>Choose...</option>
                                    <option class="CHO GENERAL TRIAS" <?php echo e((old('drunit', $records->drunit) == "CHO GENERAL TRIAS") ? 'selected' : ''); ?>>CHO GENERAL TRIAS</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="drregion"><span class="text-danger font-weight-bold">*</span>DRU Region and Province</label>
                                <select class="form-control" name="drregion" id="drregion" required>
                                    <option value="" disabled <?php echo e((is_null(old('drregion', $records->drregion))) ? 'selected' : ''); ?>>Choose...</option>
                                    <option class="4A CAVITE" <?php echo e(($records->drregion == "4A CAVITE") ? 'selected' : ''); ?>>4A CAVITE</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for=""><span class="text-danger font-weight-bold">*</span>Philhealth No.</label>
                                <input type="text" name="" id="" class="form-control" value="<?php echo e((is_null($records->records->philhealth)) ? 'N/A' : $records->records->philhealth); ?>" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="interviewerName"><span class="text-danger font-weight-bold">*</span>Name of Interviewer</label>
                                <input type="text" name="interviewerName" id="interviewerName" class="form-control" value="<?php echo e(strtoupper(old('interviewerName', $records->interviewerName))); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="interviewerMobile"><span class="text-danger font-weight-bold">*</span>Contact Number of Interviewer</label>
                                <input type="number" name="interviewerMobile" id="interviewerMobile" class="form-control" value="<?php echo e(old('interviewerMobile', $records->interviewerMobile)); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="interviewDate"><span class="text-danger font-weight-bold">*</span>Date of Interview</label>
                                <input type="date" name="interviewDate" id="interviewDate" class="form-control" value="<?php echo e(old('interviewDate', $records->interviewDate)); ?>" max="<?php echo e(date('Y-m-d')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="informantName">Name of Informant <small><i>(If patient unavailable)</i></small></label>
                                <input type="text" name="informantName" id="informantName" class="form-control" value="<?php echo e(old('informantName', $records->informantName)); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="informantRelationship">Relationship</label>
                                <select class="form-control" name="informantRelationship" id="informantRelationship">
                                <option value="" disabled <?php echo e((is_null(old('informantRelationship', $records->informantRelationship))) ? 'selected' : ''); ?>>Choose...</option>
                                <option value="Relative" <?php echo e((old('informantRelationship', $records->informantRelationship) == "Relative") ? 'selected' : ''); ?>>Family/Relative</option>
                                <option value="Friend" <?php echo e((old('informantRelationship', $records->informantRelationship) == "Friend") ? 'selected' : ''); ?>>Friend</option>
                                <option value="Others" <?php echo e((old('informantRelationship', $records->informantRelationship) == "Others") ? 'selected' : ''); ?>>Others</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="informantMobile">Contact Number of Informant</label>
                                <input type="number" name="informantMobile" id="informantMobile" class="form-control" value="<?php echo e(old('informantMobile', $records->informantMobile)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3">
                        <div class="card-header">
                            <span class="text-danger font-weight-bold">*</span>If existing case (<i>check all that apply</i>)
                        </div>
                        <div class="card-body exCaseList">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="1" id="" name="existingCaseList[]" required <?php echo e((in_array("1", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Not applicable (New case)
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="2" id="" name="existingCaseList[]" required <?php echo e((in_array("2", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Not applicable (Unknown)
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="3" id="" name="existingCaseList[]" required <?php echo e((in_array("3", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update symptoms
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="4" id="" name="existingCaseList[]" required <?php echo e((in_array("4", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update health status
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="5" id="" name="existingCaseList[]" required <?php echo e((in_array("5", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update outcome
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="6" id="" name="existingCaseList[]" required <?php echo e((in_array("6", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update case classification
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="7" id="" name="existingCaseList[]" required <?php echo e((in_array("7", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update lab result
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="8" id="" name="existingCaseList[]" required <?php echo e((in_array("8", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update chest imaging findings
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="9" id="" name="existingCaseList[]" required <?php echo e((in_array("9", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update disposition
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="10" id="" name="existingCaseList[]" required <?php echo e((in_array("10", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Update exposure / travel history
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="11" id="ecothers" name="existingCaseList[]" required <?php echo e((in_array("11", old('existingCaseList', explode(",", $records->existingCaseList)))) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="">
                                            Others
                                        </label>
                                    </div>
                                    <div id="divECOthers">
                                        <div class="form-group mt-2">
                                            <label for="ecOthersRemarks"><span class="text-danger font-weight-bold">*</span>Specify</label>
                                          <input type="text" name="ecOthersRemarks" id="ecOthersRemarks" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pType"><span class="text-danger font-weight-bold">*</span>Type of Client</label>
                        <select class="form-control" name="pType" id="pType" required>
                        <option value="PROBABLE" <?php if(old('pType') == "PROBABLE"): ?><?php echo e('selected'); ?><?php endif; ?>>COVID-19 Case (Suspect, Probable, or Confirmed)</option>
                        <option value="CLOSE CONTACT" <?php if(old('pType') == "CLOSE CONTACT"): ?><?php echo e('selected'); ?><?php endif; ?>>Close Contact</option>
                        <option value="TESTING" <?php if(old('pType') == "TESTING"): ?><?php echo e('selected'); ?><?php endif; ?>>For RT-PCR Testing (Not a Case of Close Contact)</option>
                        </select>
                    </div>
                    <div><label for=""><span class="text-danger font-weight-bold">*</span>Testing Category/Subgroup <i>(Check all that apply)</i></label></div>
                    <div class="form-check form-check-inline testingCatOptions">
                        <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" name="testingCat[]" id="testingCat_A" value="A" required <?php echo e((in_array("A", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> A
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_B" value="B" required <?php echo e((in_array("B", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> B
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_C" value="C" required <?php echo e((in_array("C", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> C
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_D" value="D" required <?php echo e((in_array("D", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> D
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_E" value="E" required <?php echo e((in_array("E", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> E
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_F" value="F" required <?php echo e((in_array("F", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> F
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_G" value="G" required <?php echo e((in_array("G", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> G
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_H" value="H" required <?php echo e((in_array("H", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> H
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_I" value="I" required <?php echo e((in_array("I", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> I
                        </label>
                        <label class="form-check-label">
                            <input class="form-check-input ml-3" type="checkbox" name="testingCat[]" id="testingCat_J" value="J" required <?php echo e((in_array("J", explode(',', $records->testingCat))) ? 'checked' : ''); ?>> J
                        </label>
                    </div>
                    
                    <div class="card mt-3">
                        <div class="card-header font-weight-bold">Part 1. Patient Information</div>
                        <div class="card-body">
                            <div class="card mb-3">
                                <div class="card-header">1.1 Patient Profile</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Last Name</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->lname); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">First Name</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->fname); ?>" id="" disabled>
                                            </div>
                                        </div> 
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Middle Name</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->mname); ?>" id="" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Birthdate (MM/DD/YYYY)</label>
                                                <input type="text" class="form-control" value="<?php echo e(date('m/d/Y', strtotime($records->records->bdate))); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Age</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->getAge($records->records->bdate)); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Gender</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->gender); ?>" id="" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="">Civil Status</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->cs); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="">Nationality</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->nationality); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Occupation</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation)) ? 'N/A' : $records->records->occupation); ?>" id="" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="">Works in a Closed Setting</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->worksInClosedSetting); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">1.2 Current Address in the Philippines and Contact Information</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">House No./Lot/Bldg.</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->address_houseno); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Street/Purok/Sitio</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->address_street); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Barangay</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->address_brgy); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Municipality/City</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->address_city); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Province</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->address_province); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Home Phone No. (& Area Code)</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->phoneno)) ? 'N/A' : $records->records->phoneno); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Cellphone No.</label>
                                                <input type="text" class="form-control" value="<?php echo e($records->records->mobile); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Email Address</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->email)) ? 'N/A' : $records->records->email); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">1.3 Permanent Address and Contact Information (If different from current address)</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">House No./Lot/Bldg.</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaaddress_houseno)) ? "N/A" : $records->records->permaaddress_houseno); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Street/Purok/Sitio</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaaddress_street)) ? "N/A" : $records->records->permaaddress_street); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Barangay</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaaddress_brgy)) ? "N/A" : $records->records->permaaddress_brgy); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Municipality/City</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaaddress_city)) ? "N/A" : $records->records->permaaddress_city); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Province</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaaddress_province)) ? "N/A" : $records->records->permaaddress_province); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Home Phone No. (& Area Code)</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaphoneno)) ? "N/A" : $records->records->permaphoneno); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Cellphone No.</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permamobile)) ? "N/A" : $records->records->permamobile); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Email Address</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->permaemail)) ? "N/A" : $records->records->permaemail); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">1.4 Current Workplace Address and Contact Information</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Lot/Bldg.</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_lotbldg)) ? 'N/A' : $records->records->occupation_lotbldg); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Street</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_street)) ? 'N/A' : $records->records->occupation_street); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Barangay</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_brgy)) ? 'N/A' : $records->records->occupation_brgy); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Municipality/City</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_city)) ? 'N/A' : $records->records->occupation_city); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Province</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_province)) ? 'N/A' : $records->records->occupation_province); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Name of Workplace</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_name)) ? 'N/A' : $records->records->occupation_name); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Phone No./Cellphone No.</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_mobile)) ? 'N/A' : $records->records->occupation_mobile); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="">Email Address</label>
                                                <input type="text" class="form-control" value="<?php echo e((is_null($records->records->occupation_email)) ? 'N/A' : $records->records->occupation_email); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">1.5 Special Population</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="isHealthCareWorker"><span class="text-danger font-weight-bold">*</span>Health Care Worker</label>
                                                <select class="form-control" name="isHealthCareWorker" id="isHealthCareWorker" required>
                                                    <option value="1" <?php echo e((old('isHealthCareWorker', $records->isHealthCareWorker) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('isHealthCareWorker', $records->isHealthCareWorker) == 0) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divisHealthCareWorker">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="healthCareCompanyName"><span class="text-danger font-weight-bold">*</span>Name of Health Facility</label>
                                                            <input type="text" class="form-control" name="healthCareCompanyName" id="healthCareCompanyName" value="<?php echo e(old('healthCareCompanyName', $records->healthCareCompanyName)); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="healthCareCompanyLocation"><span class="text-danger font-weight-bold">*</span>Location</label>
                                                            <input type="text" class="form-control" name="healthCareCompanyLocation" id="healthCareCompanyLocation" value="<?php echo e(old('healthCareCompanyLocation', $records->healthCareCompanyLocation)); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="isOFW"><span class="text-danger font-weight-bold">*</span>Returning Overseas Filipino</label>
                                                <select class="form-control" name="isOFW" id="isOFW" required>
                                                    <option value="1" <?php echo e((old('isOFW', $records->isOFW) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('isOFW', $records->isOFW) == 0) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divisOFW">
                                                <div class="form-group">
                                                    <label for="OFWCountyOfOrigin"><span class="text-danger font-weight-bold">*</span>Country of Origin</label>
                                                    <select class="form-control" name="OFWCountyOfOrigin" id="OFWCountyOfOrigin">
                                                        <option value="" disabled <?php echo e((is_null(old('OFWCountyOfOrigin', $records->OFWCountyOfOrigin))) ? 'selected' : ''); ?>>Choose...</option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($country != 'Philippines'): ?>
                                                                <option value="<?php echo e($country); ?>" <?php echo e((old('OFWCountyOfOrigin', $records->OFWCountyOfOrigin) == $country) ? 'selected' : ''); ?>><?php echo e($country); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                  <label for="ofwType"><span class="text-danger font-weight-bold">*</span>OFW?</label>
                                                  <select class="form-control" name="ofwType" id="ofwType">
                                                    <option value="1" <?php echo e((old('ofwType', $records->ofwType) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="2" <?php echo e((old('ofwType', $records->ofwType) == "NO") ? 'selected' : ''); ?>>No (Non-OFW)</option>
                                                  </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="isFNT"><span class="text-danger font-weight-bold">*</span>Foreign National Traveler</label>
                                                <select class="form-control" name="isFNT" id="isFNT" required>
                                                    <option value="1" <?php echo e((old('isFNT', $records->isFNT) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('isFNT', $records->isFNT) == 0 || is_null(old('isFNT', $records->isFNT))) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divisFNT">
                                                <div class="form-group">
                                                    <label for="FNTCountryOfOrigin"><span class="text-danger font-weight-bold">*</span>Country of Origin</label>
                                                    <select class="form-control" name="FNTCountryOfOrigin" id="FNTCountryOfOrigin">
                                                        <option value="" disabled <?php echo e((is_null(old('FNTCountryOfOrigin', $records->FNTCountryOfOrigin))) ? 'selected' : ''); ?>>Choose...</option>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($country != 'Philippines'): ?>
                                                                <option value="<?php echo e($country); ?>" <?php echo e((old('FNTCountryOfOrigin', $records->FNTCountryOfOrigin) == $country) ? 'selected' : ''); ?>><?php echo e($country); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="isLSI"><span class="text-danger font-weight-bold">*</span>Locally Stranded Individual/APOR/Traveler</label>
                                                <select class="form-control" name="isLSI" id="isLSI" required>
                                                    <option value="1" <?php echo e((old('isLSI', $records->isLSI) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('isLSI', $records->isLSI) == 0 || is_null(old('isLSI', $records->isLSI))) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divisLSI">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                          <label for="LSIProvince"><span class="text-danger font-weight-bold">*</span>Province of Origin</label>
                                                          <select class="form-control" name="LSIProvince" id="LSIProvince">
                                                                <option value="" disabled <?php echo e((is_null(old('LSIProvince', $records->LSIProvince))) ? 'selected' : ''); ?>>Choose...</option>
                                                          </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="LSICity"><span class="text-danger font-weight-bold">*</span>City of Origin</label>
                                                            <select class="form-control" name="LSICity" id="LSICity">
                                                                  <option value="" disabled <?php echo e((is_null(old('LSICity', $records->LSICity))) ? 'selected' : ''); ?>>Choose...</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                  <label for="lsiType"><span class="text-danger font-weight-bold">*</span>Type</label>
                                                  <select class="form-control" name="lsiType" id="lsiType">
                                                    <option value="1" <?php echo e((old('lsiType', $records->lsiType) == 1) ? 'selected' : ''); ?>>Locally Stranted Individual</option>
                                                    <option value="0" <?php echo e((old('lsiType', $records->lsiType) == 2) ? 'selected' : ''); ?>>Authorized Person Outside Residence/Local Traveler</option>
                                                  </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>        
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="isLivesOnClosedSettings"><span class="text-danger font-weight-bold">*</span>Lives in Closed Settings</label>
                                                <select class="form-control" name="isLivesOnClosedSettings" id="isLivesOnClosedSettings" required>
                                                    <option value="1" <?php echo e((old('isLivesOnClosedSettings', $records->isLivesOnClosedSettings) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('isLivesOnClosedSettings', $records->isLivesOnClosedSettings) == 0 || is_null(old('isLivesOnClosedSettings', $records->isLivesOnClosedSettings))) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divisLivesOnClosedSettings">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                          <label for="institutionType"><span class="text-danger font-weight-bold">*</span>Specify Institution Type</label>
                                                          <input type="text" class="form-control" name="institutionType" id="institutionType" value="<?php echo e(old('institutionType', $records->institutionType)); ?>">
                                                          <small><i>(e.g. prisons, residential facilities, retirement communities, care homes, camps etc.)</i></small>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="institutionName"><span class="text-danger font-weight-bold">*</span>Name of Institution</label>
                                                            <input type="text" class="form-control" name="institutionName" id="institutionName" value="<?php echo e(old('institutionName', $records->institutionName)); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label for="isIndg"><span class="text-danger font-weight-bold">*</span>Indigenous Person</label>
                                              <select class="form-control" name="isIndg" id="isIndg" required>
                                                <option value="1" <?php echo e((old('isIndg', $records->isIndg) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                <option value="0" <?php echo e((old('isIndg', $records->isIndg) == 0 || is_null(old('isIndg', $records->isIndg))) ? 'selected' : ''); ?>>No</option>
                                              </select>
                                            </div>
                                            <div id="divIsIndg">
                                                <div class="form-group">
                                                  <label for="indgSpecify"><span class="text-danger font-weight-bold">*</span>Specify Group</label>
                                                  <input type="text" class="form-control" name="indgSpecify" id="indgSpecify" value="<?php echo e(old('indgSpecify', $records->indgSpecify)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-header font-weight-bold">Part 2. Case Investigation Details</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header">2.1 Consultation Information</div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="havePreviousCovidConsultation"><span class="text-danger font-weight-bold">*</span>Have previous COVID-19 related consultation?</label>
                                                <select class="form-control" name="havePreviousCovidConsultation" id="havePreviousCovidConsultation" required>
                                                    <option value="" selected disabled>Choose...</option>
                                                    <option value="1" <?php echo e((old('havePreviousCovidConsultation', $records->havePreviousCovidConsultation) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                    <option value="0" <?php echo e((old('havePreviousCovidConsultation', $records->havePreviousCovidConsultation) == 0) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                            <div id="divYes1">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="facilityNameOfFirstConsult"><span class="text-danger font-weight-bold">*</span>Name of facility where first consult was done</label>
                                                            <input type="text" class="form-control" name="facilityNameOfFirstConsult" id="facilityNameOfFirstConsult" value="<?php echo e(old('facilityNameOfFirstConsult', $records->facilityNameOfFirstConsult)); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="dateOfFirstConsult"><span class="text-danger font-weight-bold">*</span>Date of First Consult</label>
                                                            <input type="date" class="form-control" name="dateOfFirstConsult" id="dateOfFirstConsult" value="<?php echo e(old('dateOfFirstConsult', $records->dateOfFirstConsult)); ?>" max="<?php echo e(date('Y-m-d')); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header">2.2 Disposition at Time of Report</div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="dispositionType"><span class="text-danger font-weight-bold">*</span>Status</label>
                                                <select class="form-control" name="dispositionType" id="dispositionType">
                                                    <option value="" <?php echo e((is_null(old('dispositionType', $records->dispoType))) ? 'selected' : ''); ?>>N/A</option>
                                                    <option value="1" <?php echo e((old('dispositionType', $records->dispoType) == 1) ? 'selected' : ''); ?>>Admitted in hospital</option>
                                                    <option value="2" <?php echo e((old('dispositionType', $records->dispoType) == 2) ? 'selected' : ''); ?>>Admitted in isolation/quarantine facility</option>
                                                    <option value="3" <?php echo e((old('dispositionType', $records->dispoType) == 3) ? 'selected' : ''); ?>>In home isolation/quarantine</option>
                                                    <option value="4" <?php echo e((old('dispositionType', $records->dispoType) == 4) ? 'selected' : ''); ?>>Discharged to home</option>
                                                    <option value="5" <?php echo e((old('dispositionType', $records->dispoType) == 5) ? 'selected' : ''); ?>>Others</option>
                                                </select>
                                            </div>
                                            <div id="divYes5">
                                                <div class="form-group">
                                                    <label for="dispositionName" id="dispositionlabel"></label>
                                                    <input type="text" class="form-control" name="dispositionName" id="dispositionName" value="<?php echo e(old('dispositionName', $records->dispoName)); ?>">
                                                </div>
                                            </div>
                                            <div id="divYes6">
                                                <div class="form-group">
                                                    <label for="dispositionDate" id="dispositiondatelabel"></label>
                                                    <input type="datetime-local" class="form-control" name="dispositionDate" id="dispositionDate" value="<?php echo e(old('dispositionDate', $records->dispoDate)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header"><span class="text-danger font-weight-bold">*</span>2.3 Health Status at Consult</div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <select class="form-control" name="healthStatus" id="healthStatus" required>
                                                    <option value="Asymptomatic" <?php echo e((old('healthStatus', $records->healthStatus) == 'Asymptomatic') ? 'selected' : ''); ?>>Asymptomatic </option>
                                                    <option value="Mild" <?php echo e((old('healthStatus', $records->healthStatus) == 'Mild') ? 'selected' : ''); ?>>Mild</option>
                                                    <option value="Moderate" <?php echo e((old('healthStatus', $records->healthStatus) == 'Moderate') ? 'selected' : ''); ?>>Moderate</option>
                                                    <option value="Severe" <?php echo e((old('healthStatus', $records->healthStatus) == 'Severe') ? 'selected' : ''); ?>>Severe</option>
                                                    <option value="Critical" <?php echo e((old('healthStatus', $records->healthStatus) == 'Critical') ? 'selected' : ''); ?>>Critical</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card mb-3">
                                        <div class="card-header"><span class="text-danger font-weight-bold">*</span>2.4 Case Classification</div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <select class="form-control" name="caseClassification" id="caseClassification" required>
                                                    <option value="Probable" <?php echo e((old('caseClassification', $records->caseClassification) == 'Probable') ? 'selected' : ''); ?>>Probable</option>
                                                    <option value="Suspect" <?php echo e((old('caseClassification', $records->caseClassification) == 'Suspect') ? 'selected' : ''); ?>>Suspect</option>
                                                    <option value="Confirmed" <?php echo e((old('caseClassification', $records->caseClassification) == 'Confirmed') ? 'selected' : ''); ?>>Confirmed</option>
                                                    <option value="Non-COVID-19 Case" <?php echo e((old('caseClassification', $records->caseClassification) == 'Non-COVID-19 Case') ? 'selected' : ''); ?>>Non-COVID-19 Case</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">2.5 Clinical Information</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label for="dateOnsetOfIllness">Date of Onset of Illness</label>
                                              <input type="date" class="form-control" name="dateOnsetOfIllness" id="dateOnsetOfIllness" max="<?php echo e(old('dateOnsetOfIllness', $records->dateOnsetOfIllness)); ?>">
                                            </div>
                                            <div class="card">
                                                <div class="card-header">Signs and Symptoms (Check all that apply)</div>
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Asymptomatic"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck1"
                                                                  <?php echo e((in_array("Asymptomatic", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck1">Asymptomatic</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Fever"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck2"
                                                                  <?php echo e((in_array("Fever", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck2">Fever</label>
                                                            </div>
                                                            <div id="divFeverChecked">
                                                                <div class="form-group mt-2">
                                                                  <label for="SASFeverDeg">Degrees (in Celcius)</label>
                                                                  <input type="number" class="form-control" name="SASFeverDeg" id="SASFeverDeg" min="1" value="<?php echo e(old('SASFeverDeg')); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Cough"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck3"
                                                                  <?php echo e((in_array("Cough", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck3">Cough</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="General Weakness"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck4"
                                                                  <?php echo e((in_array("General Weakness", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck4">General Weakness</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Fatigue"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck5"
                                                                  <?php echo e((in_array("Fatigue", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck5">Fatigue</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Headache"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck6"
                                                                  <?php echo e((in_array("Headache", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck6">Headache</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Myalgia"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck7"
                                                                  <?php echo e((in_array("Myalgia", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck7">Myalgia</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Sore throat"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck8"
                                                                  <?php echo e((in_array("Sore throat", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck8">Sore Throat</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Coryza"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck9"
                                                                  <?php echo e((in_array("Coryza", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck9">Coryza</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Dyspnea"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck10"
                                                                  <?php echo e((in_array("Dyspnea", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck10">Dyspnea</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Anorexia"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck11"
                                                                  <?php echo e((in_array("Anorexia", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck11">Anorexia</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Nausea"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck12"
                                                                  <?php echo e((in_array("Nausea", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck12">Nausea</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Vomiting"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck13"
                                                                  <?php echo e((in_array("Vomiting", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck13">Vomiting</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Diarrhea"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck14"
                                                                  <?php echo e((in_array("Diarrhea", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck14">Diarrhea</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Altered Mental Status"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck15"
                                                                  <?php echo e((in_array("Altered Mental Status", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck15">Altered Mental Status</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Anosmia (Loss of Smell)"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck16"
                                                                  <?php echo e((in_array("Anosmia (Loss of Smell)", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck16">Anosmia <small>(loss of smell, w/o any identified cause)</small></label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Ageusia (Loss of Taste)"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck17"
                                                                  <?php echo e((in_array("Ageusia (Loss of Taste)", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck17">Ageusia <small>(loss of taste, w/o any identified cause)</small></label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Others"
                                                                  name="sasCheck[]"
                                                                  id="signsCheck18"
                                                                  <?php echo e((in_array("Others", old('sasCheck', explode(",", $records->SAS)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="signsCheck18">Others</label>
                                                            </div>
                                                            <div id="divSASOtherChecked">
                                                                <div class="form-group mt-2">
                                                                  <label for="SASOtherRemarks">Specify Findings</label>
                                                                  <input type="text" class="form-control" name="SASOtherRemarks" id="SASOtherRemarks" value="<?php echo e(old('SASOtherRemarks')); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="card mb-3">
                                                <div class="card-header">Comorbidities (Check all that apply if present)</div>
                                                <div class="card-body">
                                                    <div class="row comoOpt">
                                                        <div class="col-md-6">
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="None"
                                                                  name="comCheck[]"
                                                                  id="comCheck1"
                                                                  required
                                                                  <?php echo e((in_array("None", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck1">None</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Hypertension"
                                                                  name="comCheck[]"
                                                                  id="comCheck2"
                                                                  required
                                                                  <?php echo e((in_array("Hypertension", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck2">Hypertension</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Diabetes"
                                                                  name="comCheck[]"
                                                                  id="comCheck3"
                                                                  required
                                                                  <?php echo e((in_array("Diabetes", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck3">Diabetes</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Heart Disease"
                                                                  name="comCheck[]"
                                                                  id="comCheck4"
                                                                  required
                                                                  <?php echo e((in_array("Heart Disease", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck4">Heart Disease</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Lung Disease"
                                                                  name="comCheck[]"
                                                                  id="comCheck5"
                                                                  required
                                                                  <?php echo e((in_array("Lung Disease", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck5">Lung Disease</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Gastrointestinal"
                                                                  name="comCheck[]"
                                                                  id="comCheck6"
                                                                  required
                                                                  <?php echo e((in_array("Gastrointestinal", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck6">Gastrointestinal</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Genito-urinary"
                                                                  name="comCheck[]"
                                                                  id="comCheck7"
                                                                  required
                                                                  <?php echo e((in_array("Genito-urinary", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck7">Genito-urinary</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Neurological Disease"
                                                                  name="comCheck[]"
                                                                  id="comCheck8"
                                                                  required
                                                                  <?php echo e((in_array("Neurological Disease", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck8">Neurological Disease</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Cancer"
                                                                  name="comCheck[]"
                                                                  id="comCheck9"
                                                                  required
                                                                  <?php echo e((in_array("Cancer", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck9">Cancer</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input
                                                                  class="form-check-input"
                                                                  type="checkbox"
                                                                  value="Others"
                                                                  name="comCheck[]"
                                                                  id="comCheck10"
                                                                  required
                                                                  <?php echo e((in_array("Others", old('comCheck', explode(",", $records->COMO)))) ? 'checked' : ''); ?>

                                                                />
                                                                <label class="form-check-label" for="comCheck10">Others</label>
                                                            </div>
                                                            <div id="divComOthersChecked">
                                                                <div class="form-group mt-2">
                                                                  <label for="COMOOtherRemarks">Specify Findings</label>
                                                                  <input type="text" class="form-control" name="COMOOtherRemarks" id="COMOOtherRemarks" value="<?php echo e(old('COMOOtherRemarks')); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for=""><span class="text-danger font-weight-bold">*</span>Pregnant?</label>
                                                        <input type="text" class="form-control" value="<?php echo e(($records->records->isPregnant == 1) ? "Yes" : "No"); ?>" disabled>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="PregnantLMP"><span class="text-danger font-weight-bold">*</span>LMP</label>
                                                        <input type="date" class="form-control" name="PregnantLMP" id="PregnantLMP" value="<?php echo e(old('PregnantLMP', $records->PregnantLMP)); ?>" <?php echo e(($records->records->gender == "FEMALE" && $records->records->isPregnant == 1) ? 'required' : 'disabled'); ?>>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                              <label for="highRiskPregnancy"><span class="text-danger font-weight-bold">*</span>High Risk Pregnancy?</label>
                                              <select class="form-control" name="highRiskPregnancy" id="highRiskPregnancy">
                                                <option value="0" <?php echo e((is_null(old('highRiskPregnancy', $records->pregnantHighRisk)) || old('highRiskPregnancy', $records->pregnantHighRisk) == 0) ? 'selected' : ''); ?>>No</option>
                                                <option value="1" <?php echo e((old('highRiskPregnancy', $records->pregnantHighRisk) == 1) ? 'selected' : ''); ?>>Yes</option>
                                              </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group mt-3">
                                      <label for="diagWithSARI"><span class="text-danger font-weight-bold">*</span>Was diagnosed to have Severe Acute Respiratory Illness?</label>
                                      <select class="form-control" name="diagWithSARI" id="diagWithSARI" required>
                                        <option value="1" <?php echo e((old('diagWithSARI', $records->diagWithSARI) == 1) ? 'selected' : ''); ?>>Yes</option>
                                        <option value="0" <?php echo e((is_null(old('diagWithSARI', $records->diagWithSARI)) || old('diagWithSARI', $records->diagWithSARI) == 0) ? 'selected' : ''); ?>>No</option>
                                      </select>
                                    </div>
                                    <div class="card">
                                        <div class="card-header">
                                            Chest imaging findings suggestive of COVID-19
                                            <hr>
                                            <span class="text-danger font-weight-bold">*</span>Imaging Done
                                        </div>
                                        <div class="card-body imaOptions">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                      <label for="">Date done</label>
                                                      <input type="date" class="form-control" name="imagingDoneDate" id="imagingDoneDate" value="<?php echo e(old('imagingDoneDate', $records->imagingDoneDate)); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                      <label for="imagingDone">Imaging done</label>
                                                      <select class="form-control" name="imagingDone" id="imagingDone" required>
                                                        <option value="None" <?php echo e((old('imagingDone', $records->imagingDone) == "None") ? 'selected' : ''); ?>>None</option>
                                                        <option value="Chest Radiography" <?php echo e((old('imagingDone', $records->imagingDone) == "Chest Radiography") ? 'selected' : ''); ?>>Chest Radiography</option>
                                                        <option value="Chest CT" <?php echo e((old('imagingDone', $records->imagingDone) == "Chest CT") ? 'selected' : ''); ?>>Chest CT</option>
                                                        <option value="Lung Ultrasound" <?php echo e((old('imagingDone', $records->imagingDone) == "Lung Ultrasound") ? 'selected' : ''); ?>>Lung Ultrasound</option>
                                                      </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                      <label for="imagingResult">Results</label>
                                                      <select class="form-control" name="imagingResult" id="imagingResult" aria-valuemax="">
                                                      </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-8">
                                                </div>
                                                <div class="col-md-4">
                                                    <div id="divImagingOthers">
                                                        <div class="form-group">
                                                          <label for="imagingOtherFindings"><span class="text-danger font-weight-bold">*</span>Specify findings</label>
                                                          <input type="text" class="form-control" name="imagingOtherFindings" id="imagingOtherFindings" value="<?php echo e(old('imagingOtherFindings', $records->imagingOtherFindings)); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header">2.6 Laboratory Information</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="testedPositiveUsingRTPCRBefore"><span class="text-danger font-weight-bold">*</span>Have you ever tested positive using RT-PCR before?</label>
                                                <select class="form-control" name="testedPositiveUsingRTPCRBefore" id="testedPositiveUsingRTPCRBefore" required>
                                                  <option value="1" <?php echo e((old('testedPositiveUsingRTPCRBefore', $records->testedPositiveUsingRTPCRBefore) == 1) ? 'selected' : ''); ?>>Yes</option>
                                                  <option value="0" <?php echo e((is_null(old('testedPositiveUsingRTPCRBefore', $records->testedPositiveUsingRTPCRBefore)) || old('testedPositiveUsingRTPCRBefore', $records->testedPositiveUsingRTPCRBefore) == 0) ? 'selected' : ''); ?>>No</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="testedPositiveNumOfSwab"><span class="text-danger font-weight-bold">*</span>Number of previous RT-PCR swabs done</label>
                                                <input type="number" class="form-control" name="testedPositiveNumOfSwab" id="testedPositiveNumOfSwab" min="0" value="<?php echo e(old('testedPositiveNumOfSwab', $records->testedPositiveNumOfSwab)); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="divIfTestedPositiveUsingRTPCR">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="testedPositiveSpecCollectedDate"><span class="text-danger font-weight-bold">*</span>Date of Specimen Collection</label>
                                                    <input type="date" class="form-control" name="testedPositiveSpecCollectedDate" id="testedPositiveSpecCollectedDate" max="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('testedPositiveSpecCollectedDate', $records->testedPositiveSpecCollectedDate)); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                  <label for="testedPositiveLab"><span class="text-danger font-weight-bold">*</span>Laboratory</label>
                                                  <input type="text" class="form-control" name="testedPositiveLab" id="testedPositiveLab" value="<?php echo e(old('testedPositiveLab', $records->testedPositiveLab)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                              <label for="testDateCollected1"><span class="text-danger font-weight-bold">*</span>1. Date Collected</label>
                                              <input type="date" class="form-control" name="testDateCollected1" id="testDateCollected1" value="<?php echo e(old('testDateCollected1', $records->testDateCollected1)); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="testDateReleased1">Date released</label>
                                                <input type="date" class="form-control" name="testDateReleased1" id="testDateReleased1" value="<?php echo e(old('testDateReleased1', $records->testDateReleased1)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="testLaboratory1"><span class="text-danger font-weight-bold">*</span>Laboratory</label>
                                                <input type="text" class="form-control" name="testLaboratory1" id="testLaboratory1" value="<?php echo e(old('testLaboratory1', $records->testLaboratory1)); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                              <label for="testType1"><span class="text-danger font-weight-bold">*</span>Type of test</label>
                                              <select class="form-control" name="testType1" id="testType1" required>
                                                <option value="OPS" <?php echo e((old('testType1', $records->testType1) == 'OPS') ? 'selected' : ''); ?>>RT-PCR (OPS)</option>
                                                <option value="NPS" <?php echo e((old('testType1', $records->testType1) == 'NPS') ? 'selected' : ''); ?>>RT-PCR (NPS)</option>
                                                <option value="OPS AND NPS" <?php echo e((old('testType1', $records->testType1) == 'OPS AND NPS') ? 'selected' : ''); ?>>RT-PCR (OPS and NPS)</option>
                                                <option value="ANTIGEN" <?php echo e((old('testType1', $records->testType1) == 'ANTIGEN') ? 'selected' : ''); ?>>Antigen Test</option>
                                                <option value="ANTIBODY" <?php echo e((old('testType1', $records->testType1) == 'ANTIBODY') ? 'selected' : ''); ?>>Antibody Test</option>
                                                <option value="OTHERS" <?php echo e((old('testType1', $records->testType1) == 'OTHERS') ? 'selected' : ''); ?>>Others</option>
                                              </select>
                                            </div>
                                            <div id="divTypeOthers1">
                                                <div class="form-group">
                                                  <label for="testTypeOtherRemarks1">Specify</label>
                                                  <input type="text" class="form-control" name="testTypeOtherRemarks1" id="testTypeOtherRemarks1" value="<?php echo e(old('testTypeOtherRemarks1', $records->testTypeOtherRemarks1)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                              <label for="testResult1"><span class="text-danger font-weight-bold">*</span>Results</label>
                                              <select class="form-control" name="testResult1" id="testResult1" required>
                                                <option value="PENDING" <?php echo e((old('testResult1', $records->testResult1) == 'PENDING') ? 'selected' : ''); ?>>Pending</option>
                                                <option value="POSITIVE" <?php echo e((old('testResult1', $records->testResult1) == 'POSITIVE') ? 'selected' : ''); ?>>Positive</option>
                                                <option value="NEGATIVE" <?php echo e((old('testResult1', $records->testResult1) == 'NEGATIVE') ? 'selected' : ''); ?>>Negative</option>
                                                <option value="EQUIVOCAL" <?php echo e((old('testResult1', $records->testResult1) == 'EQUIVOCAL') ? 'selected' : ''); ?>>Equivocal</option>
                                                <option value="OTHERS" <?php echo e((old('testResult1', $records->testResult1) == 'OTHERS') ? 'selected' : ''); ?>>Others</option>
                                              </select>
                                            </div>
                                            <div id="divResultOthers1">
                                                <div class="form-group">
                                                    <label for="testResultOtherRemarks1">Specify</label>
                                                    <input type="text" class="form-control" name="testResultOtherRemarks1" id="testResultOtherRemarks1" value="<?php echo e(old('testResultOtherRemarks1', $records->testResultOtherRemarks1)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                              <label for="testDateCollected2">2. Date Collected</label>
                                              <input type="date" class="form-control" name="testDateCollected2" id="testDateCollected2" value="<?php echo e(old('testDateCollected2', $records->testDateCollected2)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="testDateReleased2">Date released</label>
                                                <input type="date" class="form-control" name="testDateReleased2" id="testDateReleased2" value="<?php echo e(old('testDateReleased2', $records->testDateReleased2)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="testLaboratory2">Laboratory</label>
                                                <input type="text" class="form-control" name="testLaboratory2" id="testLaboratory2" value="<?php echo e(old('testLaboratory2', $records->testLaboratory2)); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                              <label for="testType2">Type of test</label>
                                              <select class="form-control" name="testType2" id="testType2">
                                                    <option value="N/A">N/A</option>
                                                    <option value="OPS" <?php echo e((old('testType2', $records->testType2) == 'OPS') ? 'selected' : ''); ?>>RT-PCR (OPS)</option>
                                                    <option value="NPS" <?php echo e((old('testType2', $records->testType2) == 'NPS') ? 'selected' : ''); ?>>RT-PCR (NPS)</option>
                                                    <option value="OPS AND NPS" <?php echo e((old('testType2', $records->testType2) == 'OPS AND NPS') ? 'selected' : ''); ?>>RT-PCR (OPS and NPS)</option>
                                                    <option value="ANTIGEN" <?php echo e((old('testType2', $records->testType2) == 'ANTIGEN') ? 'selected' : ''); ?>>Antigen Test</option>
                                                    <option value="ANTIBODY" <?php echo e((old('testType2', $records->testType2) == 'ANTIBODY') ? 'selected' : ''); ?>>Antibody Test</option>
                                                    <option value="OTHERS" <?php echo e((old('testType2', $records->testType2) == 'OTHERS') ? 'selected' : ''); ?>>Others</option>
                                              </select>
                                            </div>
                                            <div id="divTypeOthers2">
                                                <div class="form-group">
                                                  <label for="testTypeOtherRemarks2">Specify</label>
                                                  <input type="text" class="form-control" name="testTypeOtherRemarks2" id="testTypeOtherRemarks2" value="<?php echo e(old('testTypeOtherRemarks2', $records->testTypeOtherRemarks2)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                              <label for="testResult2">Results</label>
                                              <select class="form-control" name="testResult2" id="testResult2">
                                                <option value="PENDING" <?php echo e((old('testResult2', $records->testResult2) == 'PENDING') ? 'selected' : ''); ?>>Pending</option>
                                                <option value="POSITIVE" <?php echo e((old('testResult2', $records->testResult2) == 'POSITIVE') ? 'selected' : ''); ?>>Positive</option>
                                                <option value="NEGATIVE" <?php echo e((old('testResult2', $records->testResult2) == 'NEGATIVE') ? 'selected' : ''); ?>>Negative</option>
                                                <option value="EQUIVOCAL" <?php echo e((old('testResult2', $records->testResult2) == 'EQUIVOCAL') ? 'selected' : ''); ?>>Equivocal</option>
                                                <option value="OTHERS" <?php echo e((old('testResult2', $records->testResult2) == 'OTHERS') ? 'selected' : ''); ?>>Others</option>
                                              </select>
                                            </div>
                                            <div id="divResultOthers2">
                                                <div class="form-group">
                                                    <label for="testResultOtherRemarks2">Specify</label>
                                                    <input type="text" class="form-control" name="testResultOtherRemarks2" id="testResultOtherRemarks2" value="<?php echo e(old('testResultOtherRemarks2', $records->testResultOtherRemarks2)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">2.7 Outcome/Condition at Time of Report</div>
                                <div class="card-body">
                                    <div class="form-group">
                                      <label for="outcomeCondition"><span class="text-danger font-weight-bold">*</span>Select Condition</label>
                                      <select class="form-control" name="outcomeCondition" id="outcomeCondition">
                                        <option value="" <?php echo e((is_null(old('outcomeCondition', $records->outcomeCondition))) ? 'selected' : ''); ?>>N/A</option>
                                        <option value="Active" <?php echo e((old('outcomeCondition', $records->outcomeCondition) == 'Active') ? 'selected' : ''); ?>>Active (Currently admitted or in isolation/quarantine)</option>
                                        <option value="Recovered" <?php echo e((old('outcomeCondition', $records->outcomeCondition) == 'Recovered') ? 'selected' : ''); ?>>Recovered</option>
                                        <option value="Died" <?php echo e((old('outcomeCondition', $records->outcomeCondition) == 'Died') ? 'selected' : ''); ?>>Died</option>
                                      </select>
                                    </div>
                                    <div id="ifOutcomeRecovered">
                                        <div class="form-group">
                                          <label for="outcomeRecovDate"><span class="text-danger font-weight-bold">*</span>Date of Recovery</label>
                                          <input type="date" class="form-control" name="outcomeRecovDate" id="outcomeRecovDate" max="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('outcomeRecovDate', $records->outcomeRecovDate)); ?>">
                                        </div>
                                    </div>
                                    <div id="ifOutcomeDied">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="outcomeDeathDate"><span class="text-danger font-weight-bold">*</span>Date of Death</label>
                                                    <input type="date" class="form-control" name="outcomeDeathDate" id="outcomeDeathDate" max="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('outcomeDeathDate', $records->outcomeDeathDate)); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="deathImmeCause"><span class="text-danger font-weight-bold">*</span>Immediate Cause</label>
                                                    <input type="text" class="form-control" name="deathImmeCause" id="deathImmeCause" value="<?php echo e(old('deathImmeCause', $records->deathImmeCause)); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="deathAnteCause">Antecedent Cause</label>
                                                    <input type="text" class="form-control" name="deathAnteCause" id="deathAnteCause" value="<?php echo e(old('deathAnteCause', $records->deathAnteCause)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="deathUndeCause">Underlying Cause</label>
                                                    <input type="text" class="form-control" name="deathUndeCause" id="deathUndeCause" value="<?php echo e(old('deathUndeCause', $records->deathUndeCause)); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="deathUndeCause">Contributory Conditions</label>
                                                    <input type="text" class="form-control" name="contriCondi" id="contriCondi" value="<?php echo e(old('contriCondi', $records->contriCondi)); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-header font-weight-bold">Part 3. Contact Tracing: Exposure and Travel History</div>
                        <div class="card-body">
                            <div class="card mb-3">
                                <div class="card-header">15. Exposure History</div>
                                <div class="card-body">
                                    <div class="form-group">
                                      <label for="expoitem1"><span class="text-danger font-weight-bold">*</span>History of exposure to known probable and/or confirmed COVID-19 case 14 days before the onset of signs and symptoms?  OR If Asymptomatic, 14 days before swabbing or specimen collection?</label>
                                      <select class="form-control" name="expoitem1" id="expoitem1" required>
                                            <option value="2" <?php echo e((old('expoitem1', $records->expoitem1) == 2) ? 'selected' : ''); ?>>No</option>
                                            <option value="1" <?php echo e((old('expoitem1', $records->expoitem1) == 1) ? 'selected' : ''); ?>>Yes</option>
                                            <option value="3" <?php echo e((old('expoitem1', $records->expoitem1) == 3) ? 'selected' : ''); ?>>Unknown</option>
                                      </select>
                                    </div>
                                    <div id="divExpoitem1">
                                        <div class="form-group">
                                          <label for=""><span class="text-danger font-weight-bold">*</span>Date of Last Contact</label>
                                          <input type="date" class="form-control" name="expoDateLastCont" id="expoDateLastCont" max="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('expoDateLastCont', $records->expoDateLastCont)); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="expoitem2"><span class="text-danger font-weight-bold">*</span>Has the patient been in a place with a known COVID-19 transmission 14 days before the onset of signs and symptoms? OR If Asymptomatic, 14 days before swabbing or specimen collection?</label>
                                        <select class="form-control" name="expoitem2" id="expoitem2" required>
                                          <option value="0" <?php echo e((old('expoitem2', $records->expoitem2) == 0) ? 'selected' : ''); ?>>No</option>
                                          <option value="1" <?php echo e((old('expoitem2', $records->expoitem2) == 1) ? 'selected' : ''); ?>>Yes, Local</option>
                                          <option value="2" <?php echo e((old('expoitem2', $records->expoitem2) == 2) ? 'selected' : ''); ?>>Yes, International</option>
                                          <option value="3" <?php echo e((old('expoitem2', $records->expoitem2) == 3) ? 'selected' : ''); ?>>Unknown exposure</option>
                                        </select>
                                    </div>
                                    <div id="divTravelInt">
                                        <div class="form-group">
                                            <label for="intCountry"><span class="text-danger font-weight-bold">*</span>If International Travel, country of origin</label>
                                            <select class="form-control" name="intCountry" id="intCountry">
                                                <option value="" <?php echo e((is_null(old('intCountry', $records->intCountry))) ? 'selected disabled' : ''); ?>>Choose...</option>
                                                  <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <?php if($country != 'Philippines'): ?>
                                                          <option value="<?php echo e($country); ?>" <?php echo e((old('intCountry', $records->intCountry) == $country) ? 'selected' : ''); ?>><?php echo e($country); ?></option>
                                                      <?php endif; ?>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="card mb-3">
                                                    <div class="card-header">Inclusive travel dates</div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                  <label for="intDateFrom">From</label>
                                                                  <input type="date" class="form-control" name="intDateFrom" id="intDateFrom" value="<?php echo e(old('intDateFrom', $records->intDateFrom)); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="intDateTo">From</label>
                                                                    <input type="date" class="form-control" name="intDateTo" id="intDateTo" value="<?php echo e(old('intDateTo', $records->intDateTo)); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="intWithOngoingCovid">With ongoing COVID-19 community transmission?</label>
                                                    <select class="form-control" name="intWithOngoingCovid" id="intWithOngoingCovid">
                                                      <option value="NO" <?php echo e((old('intWithOngoingCovid', $records->intWithOngoingCovid) == "NO") ? 'selected' : ''); ?>>No</option>
                                                      <option value="YES" <?php echo e((old('intWithOngoingCovid', $records->intWithOngoingCovid) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                          <label for="intVessel">Airline/Sea vessel</label>
                                                          <input type="text" class="form-control" name="intVessel" id="intVessel" value="<?php echo e(old('intVessel', $records->intVessel)); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="intVesselNo">Flight/Vessel Number</label>
                                                            <input type="text" class="form-control" name="intVesselNo" id="intVesselNo" value="<?php echo e(old('intVesselNo', $records->intVesselNo)); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="intDateDepart">Date of departure</label>
                                                            <input type="date" class="form-control" name="intDateDepart" id="intDateDepart" value="<?php echo e(old('intDateDepart', $records->intDateDepart)); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="intDateArrive">Date of arrival in PH</label>
                                                            <input type="date" class="form-control" name="intDateArrive" id="intDateArrive" value="<?php echo e(old('intDateArrive', $records->intDateArrive)); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="divTravelLoc">
                                        <div class="card">
                                            <div class="card-header">
                                                If Local Travel, specify travel places (<i>Check all that apply, provide name of facility, address, and inclusive travel dates</i>)
                                            </div>
                                            <div class="card-body">
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                        <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited1" value="Health Facility" <?php echo e((in_array("Health Facility", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                        Health Facility
                                                      </label>
                                                </div>
                                                <div id="divLocal1" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName1">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName1" id="locName1" value="<?php echo e(old('locName1', $records->locName1)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress1">Location</label>
                                                                <input class="form-control" type="text" name="locAddress1" id="locAddress1" value="<?php echo e(old('locAddress1', $records->locAddress1)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom1">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom1" id="locDateFrom1" value="<?php echo e(old('locDateFrom1', $records->locDateFrom1)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo1">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo1" id="locDateTo1" value="<?php echo e(old('locDateTo1', $records->locDateTo1)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid1">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid1" id="locWithOngoingCovid1">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid1', $records->locWithOngoingCovid1) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid1', $records->locWithOngoingCovid1) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited2" value="Closed Settings" <?php echo e((in_array("Closed Settings", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Closed Settings
                                                    </label>
                                                </div>
                                                <div id="divLocal2" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName2">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName2" id="locName2" value="<?php echo e(old('locName2', $records->locName2)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress2">Location</label>
                                                                <input class="form-control" type="text" name="locAddress2" id="locAddress2" value="<?php echo e(old('locAddress2', $records->locAddress2)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom2">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom2" id="locDateFrom2" value="<?php echo e(old('locDateFrom2', $records->locDateFrom2)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo2">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo2" id="locDateTo2" value="<?php echo e(old('locDateTo2', $records->locDateTo2)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid2">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid2" id="locWithOngoingCovid2">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid2', $records->locWithOngoingCovid2) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid2', $records->locWithOngoingCovid2) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited3" value="School" <?php echo e((in_array("School", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      School
                                                    </label>
                                                </div>
                                                <div id="divLocal3" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName3">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName3" id="locName3" value="<?php echo e(old('locName3', $records->locName3)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress3">Location</label>
                                                                <input class="form-control" type="text" name="locAddress3" id="locAddress3" value="<?php echo e(old('locAddress3', $records->locAddress3)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom3">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom3" id="locDateFrom3" value="<?php echo e(old('locDateFrom3', $records->locDateFrom3)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo3">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo3" id="locDateTo3" value="<?php echo e(old('locDateTo3', $records->locDateTo3)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid3">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid3" id="locWithOngoingCovid3">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid3', $records->locWithOngoingCovid3) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid3', $records->locWithOngoingCovid3) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited4" value="Workplace" <?php echo e((in_array("Workplace", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Workplace
                                                    </label>
                                                </div>
                                                <div id="divLocal4" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName4">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName4" id="locName4" value="<?php echo e(old('locName4', $records->locName4)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress4">Location</label>
                                                                <input class="form-control" type="text" name="locAddress4" id="locAddress4" value="<?php echo e(old('locAddress4', $records->locAddress4)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom4">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom4" id="locDateFrom4" value="<?php echo e(old('locDateFrom4', $records->locDateFrom4)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo4">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo4" id="locDateTo4" value="<?php echo e(old('locDateTo4', $records->locDateTo4)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid4">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid4" id="locWithOngoingCovid4">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid4', $records->locWithOngoingCovid4) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid4', $records->locWithOngoingCovid4) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited5" value="Market" <?php echo e((in_array("Market", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Market
                                                    </label>
                                                </div>
                                                <div id="divLocal5" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName5">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName5" id="locName5" value="<?php echo e(old('locName5', $records->locName5)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress5">Location</label>
                                                                <input class="form-control" type="text" name="locAddress5" id="locAddress5" value="<?php echo e(old('locAddress5', $records->locAddress5)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom5">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom5" id="locDateFrom5" value="<?php echo e(old('locDateFrom5', $records->locDateFrom5)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo5">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo5" id="locDateTo5" value="<?php echo e(old('locDateTo5', $records->locDateTo5)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid5">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid5" id="locWithOngoingCovid5">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid5', $records->locWithOngoingCovid5) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid5', $records->locWithOngoingCovid5) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited6" value="Social Gathering" <?php echo e((in_array("Social Gathering", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Social Gathering
                                                    </label>
                                                </div>
                                                <div id="divLocal6" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName6">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName6" id="locName6" value="<?php echo e(old('locName6', $records->locName6)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress6">Location</label>
                                                                <input class="form-control" type="text" name="locAddress6" id="locAddress6" value="<?php echo e(old('locAddress6', $records->locAddress6)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom6">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom6" id="locDateFrom6" value="<?php echo e(old('locDateFrom6', $records->locDateFrom6)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo6">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo6" id="locDateTo6" value="<?php echo e(old('locDateTo6', $records->locDateTo6)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid6">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid6" id="locWithOngoingCovid6">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid6', $records->locWithOngoingCovid6) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid6', $records->locWithOngoingCovid6) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited7" value="Others" <?php echo e((in_array("Others", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Others
                                                    </label>
                                                </div>
                                                <div id="divLocal7" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locName7">Name of Place</label>
                                                              <input class="form-control" type="text" name="locName7" id="locName7" value="<?php echo e(old('locName7', $records->locName7)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="locAddress7">Location</label>
                                                                <input class="form-control" type="text" name="locAddress7" id="locAddress7" value="<?php echo e(old('locAddress7', $records->locAddress7)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="card">
                                                                <div class="card-header">Inclusive Travel Dates</div>
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateFrom7">From</label>
                                                                                <input class="form-control" type="date" name="locDateFrom7" id="locDateFrom7" value="<?php echo e(old('locDateFrom7', $records->locDateFrom7)); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label for="locDateTo7">To</label>
                                                                                <input class="form-control" type="date" name="locDateTo7" id="locDateTo7" value="<?php echo e(old('locDateTo7', $records->locDateTo7)); ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                              <label for="locWithOngoingCovid7">With ongoing COVID-19 Community Transmission?</label>
                                                              <select class="form-control" name="locWithOngoingCovid7" id="locWithOngoingCovid7">
                                                                <option value="NO" <?php echo e((old('locWithOngoingCovid7', $records->locWithOngoingCovid7) == "NO") ? 'selected' : ''); ?>>No</option>
                                                                <option value="YES" <?php echo e((old('locWithOngoingCovid7', $records->locWithOngoingCovid7) == "YES") ? 'selected' : ''); ?>>Yes</option>
                                                              </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label">
                                                      <input type="checkbox" class="form-check-input" name="placevisited[]" id="placevisited8" value="Transport Service" <?php echo e((in_array("Transport Service", old('placevisited', explode(",", $records->placevisited)))) ? 'checked' : ''); ?>>
                                                      Transport Service
                                                    </label>
                                                </div>
                                                <div id="divLocal8" class="my-3">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                              <label for="localVessel1">1. Airline/Sea vessel/Bus line/Train</label>
                                                              <input type="text" class="form-control" name="localVessel1" id="localVessel1" value="<?php echo e(old('localVessel1', $records->localVessel1)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localVesselNo1">Flight/Vessel/Bus No.</label>
                                                                <input type="text" class="form-control" name="localVesselNo1" id="localVesselNo1" value="<?php echo e(old('localVesselNo1', $records->localVesselNo1)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localOrigin1">Place of Origin</label>
                                                                <input type="text" class="form-control" name="localOrigin1" id="localOrigin1" value="<?php echo e(old('localOrigin1', $records->localOrigin1)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDateDepart1">Departure Date</label>
                                                                <input type="date" class="form-control" name="localDateDepart1" id="localDateDepart1" value="<?php echo e(old('localDateDepart1', $records->localDateDepart1)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDest1">Destination</label>
                                                                <input type="text" class="form-control" name="localDest1" id="localDest1" value="<?php echo e(old('localDest1', $records->localDest1)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDateArrive1">Date of Arrival</label>
                                                                <input type="text" class="form-control" name="localDateArrive1" id="localDateArrive1" value="<?php echo e(old('localDateArrive1', $records->localDateArrive1)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                              <label for="localVessel2">2. Airline/Sea vessel/Bus line/Train</label>
                                                              <input type="text" class="form-control" name="localVessel2" id="localVessel2" value="<?php echo e(old('localVessel2', $records->localVessel2)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localVesselNo2">Flight/Vessel/Bus No.</label>
                                                                <input type="text" class="form-control" name="localVesselNo2" id="localVesselNo2" value="<?php echo e(old('localVesselNo2', $records->localVesselNo2)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localOrigin2">Place of Origin</label>
                                                                <input type="text" class="form-control" name="localOrigin2" id="localOrigin2" value="<?php echo e(old('localOrigin2', $records->localOrigin2)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDateDepart2">Departure Date</label>
                                                                <input type="date" class="form-control" name="localDateDepart2" id="localDateDepart2" value="<?php echo e(old('localDateDepart2', $records->localDateDepart2)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDest2">Destination</label>
                                                                <input type="text" class="form-control" name="localDest2" id="localDest2" value="<?php echo e(old('localDest2', $records->localDest2)); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="localDateArrive2">Date of Arrival</label>
                                                                <input type="date" class="form-control" name="localDateArrive2" id="localDateArrive2" value="<?php echo e(old('localDateArrive2', $records->localDateArrive2)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card mt-3">
                                        <div class="card-header">List the names of persons who were with you two days prior to onset of illness until this date and their contact numbers.</div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="alert alert-info" role="alert">
                                                        <p>- If symptomatic, provide names and contact numbers of persons who were with the patient two days prior to onset of illness until this date.</p>
                                                        <p>- If asymptomatic, provide names and contact numbers of persons who were with the patient on the day specimen was submitted for testing until this date.</p>
                                                    </div>
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="card">
                                                        <div class="card-header">Name</div>
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                              <input type="text" class="form-control" name="contact1Name" id="contact1Name" value="<?php echo e(old('contact1Name', $records->contact1Name)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact2Name" id="contact2Name" value="<?php echo e(old('contact2Name', $records->contact2Name)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact3Name" id="contact3Name" value="<?php echo e(old('contact3Name', $records->contact3Name)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact4Name" id="contact4Name" value="<?php echo e(old('contact4Name', $records->contact4Name)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="card">
                                                        <div class="card-header">Contact Number</div>
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact1No" id="contact1No" value="<?php echo e(old('contact1No', $records->contact1No)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact2No" id="contact2No" value="<?php echo e(old('contact2No', $records->contact2No)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact3No" id="contact3No" value="<?php echo e(old('contact3No', $records->contact3No)); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="text" class="form-control" name="contact4No" id="contact4No" value="<?php echo e(old('contact4No', $records->contact4No)); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary" id="formsubmit">Submit</button>
                </div>
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function () {

            $('#records_id').selectize();

            $('#records_id').change(function (e) { 
                e.preventDefault();
                var uid = $('#records_id').val();
                if ($('#records_id').val().length != 0) {
                    fetchRecords(uid);
                }
            }).trigger('change');

            $('#informantName').keydown(function (e) { 
                if($(this).val().length <= 0 || $(this).val() == "") {
                    $('#informantRelationship').prop({disabled: true, required: false});
                    $('#informantMobile').prop({disabled: true, required: false});
                }
                else {
                    $('#informantRelationship').val("");
                    $('#informantRelationship').prop({disabled: false, required: true});
                    $('#informantMobile').prop({disabled: false, required: true});
                }
            }).trigger('keydown');

            $('#ecothers').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divECOthers').show();
                    $('#ecOthersRemarks').prop('required', true);
                }
                else {
                    $('#divECOthers').hide();
                    $('#ecOthersRemarks').prop('required', false);
                }
            });

            $(function(){
                var requiredCheckboxes = $('.exCaseList :checkbox[required]');
                requiredCheckboxes.change(function(){
                    if(requiredCheckboxes.is(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    } else {
                        requiredCheckboxes.attr('required', 'required');
                    }
                }).trigger('change');
            });

            $(function(){
                var requiredCheckboxes = $('.testingCatOptions :checkbox[required]');
                requiredCheckboxes.change(function(){
                    if(requiredCheckboxes.is(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    } else {
                        requiredCheckboxes.attr('required', 'required');
                    }
                }).trigger('change');
            });

            $(function(){
                var requiredCheckboxes = $('.imaOptions :checkbox[required]');
                requiredCheckboxes.change(function(){
                    if(requiredCheckboxes.is(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    } else {
                        requiredCheckboxes.attr('required', 'required');
                    }
                }).trigger('change');;
            });

            $(function(){
                var requiredCheckboxes = $('.comoOpt :checkbox[required]');
                requiredCheckboxes.change(function(){
                    if(requiredCheckboxes.is(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    } else {
                        requiredCheckboxes.attr('required', 'required');
                    }
                }).trigger('change');;
            });

            $(function(){
                var requiredCheckboxes = $('.labOptions :checkbox[required]');
                requiredCheckboxes.change(function(){
                    if(requiredCheckboxes.is(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    } else {
                        requiredCheckboxes.attr('required', 'required');
                    }
                }).trigger('change');;
            });

            $('#LSICity').prop({'disabled': true, 'required': false});

            $.getJSON("<?php echo e(asset('json/refregion.json')); ?>", function(data) {
                var sorted = data.sort(function(a, b) {
                    if (a.regDesc > b.regDesc) {
                    return 1;
                    }
                    if (a.regDesc < b.regDesc) {
                    return -1;
                    }
                    return 0;
                });
                $.each(sorted, function(key, val) {
                    $("#sfacilityregion").append('<option value="'+val.regCode+'">'+val.regDesc+'</option>');
                });
            });

            $.getJSON("<?php echo e(asset('json/refprovince.json')); ?>", function(data) {
                var sorted = data.sort(function(a, b) {
                    if (a.provDesc > b.provDesc) {
                    return 1;
                    }
                    if (a.provDesc < b.provDesc) {
                    return -1;
                    }
                    return 0;
                });
                $.each(sorted, function(key, val) {
                    $("#LSIProvince").append('<option value="'+val.provCode+'">'+val.provDesc+'</option>');
                });
            });

            $('#sfacilityregion').change(function (e) {
                e.preventDefault();
                $('#facilityprovince').prop({'disabled': false, 'required': true});
                $('#facilityprovince').empty();
                $("#facilityprovince").append('<option value="" selected disabled>Choose...</option>');

                $.getJSON("<?php echo e(asset('json/refprovince.json')); ?>", function(data) {
                    var sorted = data.sort(function(a, b) {
                        if (a.provDesc > b.provDesc) {
                        return 1;
                        }
                        if (a.provDesc < b.provDesc) {
                        return -1;
                        }
                        return 0;
                    });
                    $.each(sorted, function(key, val) {
                        if($('#sfacilityregion').val() == val.regCode) {
                            $("#facilityprovince").append('<option value="'+val.provCode+'">'+val.provDesc+'</option>');
                        }
                    });
			    });
            });

            $('#LSIProvince').change(function (e) { 
                e.preventDefault();
                $('#LSICity').prop({'disabled': false, 'required': true});
                $('#LSICity').empty();
                $("#LSICity").append('<option value="" selected disabled>Choose...</option>');
                $.getJSON("<?php echo e(asset('json/refcitymun.json')); ?>", function(data) {
                    var sorted = data.sort(function(a, b) {
                        if (a.citymunDesc > b.citymunDesc) {
                        return 1;
                        }
                        if (a.citymunDesc < b.citymunDesc) {
                        return -1;
                        }
                        return 0;
                    });
                    $.each(sorted, function(key, val) {
                        if($('#LSIProvince').val() == val.provCode) {
                            $("#LSICity").append('<option value="'+val.citymunCode+'">'+val.citymunDesc+'</option>');
                        }
                    });
			    });
            });

            //$('#OFWCountyOfOrigin').selectize();
            //$('#FNTCountryOfOrigin').selectize();
        
            $('#divYes1').hide();
            $('#divYes5').hide();
            $('#divYes6').hide();
            
            $('#dispositionDate').prop("type", "datetime-local");

            $('#havePreviousCovidConsultation').change(function (e) { 
                e.preventDefault();
                if($(this).val() == '1') {
                    $('#divYes1').show();

                    $('#dateOfFirstConsult').prop('required', true);
                    $('#facilityNameOfFirstConsult').prop('required', true);
                }
                else {
                    $('#divYes1').hide();

                    $('#dateOfFirstConsult').prop('required', false);
                    $('#facilityNameOfFirstConsult').prop('required', false);
                }
            }).trigger('change');

            $('#dispositionType').change(function (e) {
                e.preventDefault();
                $('#dispositionDate').prop("type", "datetime-local");
                
                if($(this).val() == '1' || $(this).val() == '2') {
                    $('#dispositionName').prop('required', true);
                    $('#dispositionDate').prop('required', true);
                }
                else if ($(this).val() == '3' || $(this).val() == '4') {
                    $('#dispositionName').prop('required', false);
                    $('#dispositionDate').prop('required', true);
                }
                else if ($(this).val() == '5') {
                    $('#dispositionName').prop('required', true);
                    $('#dispositionDate').prop('required', false);
                }
                else if($(this).val().length == 0){
                    $('#dispositionName').prop('required', false);
                    $('#dispositionDate').prop('required', false);
                }

                if($(this).val() == '1') {
                    $('#divYes5').show();
                    $('#divYes6').show();

                    $('#dispositionlabel').text("Name of Hospital");
                    $('#dispositiondatelabel').text("Date and Time Admitted in Hospital");
                }
                if($(this).val() == '2') {
                    $('#divYes5').show();
                    $('#divYes6').show();

                    $('#dispositionlabel').text("Name of Facility");
                    $('#dispositiondatelabel').text("Date and Time Admitted in Hospital");
                }
                if($(this).val() == '3') {
                    $('#divYes5').hide();
                    $('#divYes6').show();

                    $('#dispositiondatelabel').text("Date and Time isolated/quarantined at home");
                }
                if($(this).val() == '4') {
                    $('#divYes5').hide();
                    $('#divYes6').show();

                    $('#dispositionDate').prop("type", "date");

                    $('#dispositiondatelabel').text("Date of Discharge");
                }
                if($(this).val() == '5') {
                    $('#divYes5').show();
                    $('#divYes6').hide();

                    $('#dispositionlabel').text("State Reason");
                }
                else if($(this).val().length == 0){
                    $('#divYes5').hide();
                    $('#divYes6').hide();
                }
            }).trigger('change');

            $('#isHealthCareWorker').change(function (e) { 
                e.preventDefault();
                if($(this).val() == '0') {
                    $('#divisHealthCareWorker').hide();
                    $('#healthCareCompanyName').prop('required', false);
                    $('#healthCareCompanyLocation').prop('required', false);
                }
                else {
                    $('#divisHealthCareWorker').show();
                    $('#healthCareCompanyName').prop('required', true);
                    $('#healthCareCompanyLocation').prop('required', true);
                }
            }).trigger('change');

            $('#isOFW').change(function (e) {
                if($(this).val() == '0') {
                    $('#divisOFW').hide();
                    $('#OFWCountyOfOrigin').prop('required', false);

                    /*
                    $('#oaddresslotbldg').prop({'required': false, 'disabled': true});
                    $('#oaddressstreet').prop({'required': false, 'disabled': true});
                    $('#oaddressscity').prop({'required': false, 'disabled': true});
                    $('#oaddresssprovince').prop({'required': false, 'disabled': true});
                    $('#oaddressscountry').prop({'required': false, 'disabled': true});
                    $('#placeofwork').prop({'required': false, 'disabled': true});
                    $('#employername').prop({'required': false, 'disabled': true});
                    $('#employercontactnumber').prop({'required': false, 'disabled': true});

                    $('#oaddresslotbldg').val('N/A');
                    $('#oaddressstreet').val('N/A');
                    $('#oaddressscity').val('N/A');
                    $('#oaddresssprovince').val('N/A');
                    $('#oaddressscountry').val('N/A');
                    $('#placeofwork').val('N/A');
                    $('#employername').val('N/A');
                    $('#employercontactnumber').val('N/A');
                    */
                }
                else {
                    $('#divisOFW').show();
                    var control = $('#OFWCountyOfOrigin')[0].selectize;
                    control.clear();
                    $('#oaddressscountry').val('N/A');
                    $('#OFWCountyOfOrigin').prop('required', true);

                    /*
                    $('#oaddresslotbldg').prop({required: true, disabled: false});
                    $('#oaddressstreet').prop({required: true, disabled: false});
                    $('#oaddressscity').prop({required: true, disabled: false});
                    $('#oaddresssprovince').prop({required: true, disabled: false});
                    $('#oaddressscountry').prop({required: true, disabled: false});
                    $('#placeofwork').prop({required: true, disabled: false});
                    $('#employername').prop({required: true, disabled: false});
                    $('#employercontactnumber').prop({required: true, disabled: false});

                    $('#oaddresslotbldg').val('');
                    $('#oaddressstreet').val('');
                    $('#oaddressscity').val('');
                    $('#oaddresssprovince').val('');
                    $('#placeofwork').val('');
                    $('#employername').val('');
                    $('#employercontactnumber').val('');
                    */
                }
            }).trigger('change');

            $('#OFWCountyOfOrigin').change(function (e) { 
                e.preventDefault();
                $('#oaddressscountry').val($(this).val());
            });

            $('#isFNT').change(function (e) {
                if($(this).val() == '0') {
                    $('#divisFNT').hide();
                    $('#FNTCountryOfOrigin').prop('required', false);
                }
                else {
                    $('#divisFNT').show();
                    $('#FNTCountryOfOrigin').prop('required', true);
                }
            }).trigger('change');

            $('#isLSI').change(function (e) {
                if($(this).val() == '0') {
                    $('#divisLSI').hide();
                    $('#LSIProvince').prop('required', false);
                    $('#LSICity').prop('required', false);
                }
                else {
                    $('#divisLSI').show();
                    $('#LSIProvince').prop('required', true);
                    $('#LSICity').prop('required', true);
                }
            }).trigger('change');

            $('#isLivesOnClosedSettings').change(function (e) {
                if($(this).val() == '0') {
                    $('#divisLivesOnClosedSettings').hide();
                    $('#institutionType').prop('required', false);
                    $('#institutionName').prop('required', false);
                }
                else {
                    $('#divisLivesOnClosedSettings').show();
                    $('#institutionType').prop('required', true);
                    $('#institutionName').prop('required', true);
                }
            }).trigger('change');

            $('#isIndg').change(function (e) {
                e.preventDefault();
                if($(this).val() == '0') {
                    $('#divIsIndg').hide();
                    $('#indgSpecify').prop('required', false);
                }
                else {
                    $('#divIsIndg').show();
                    $('#indgSpecify').prop('required', true);
                }
            }).trigger('change');

            $('#signsCheck2').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divFeverChecked').show();
                    $('#SASFeverDeg').prop('required', true);
                }
                else {
                    $('#divFeverChecked').hide();
                    $('#SASFeverDeg').prop('required', false);
                }
            }).trigger('change');

            $('#signsCheck18').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divSASOtherChecked').show();
                    $('#SASOtherRemarks').prop('required', true);
                }
                else {
                    $('#divSASOtherChecked').hide();
                    $('#SASOtherRemarks').prop('required', false);
                }
            }).trigger('change');

            $('#comCheck10').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divComOthersChecked').show();
                    $('#COMOOtherRemarks').prop('required', true);
                }
                else {
                    $('#divComOthersChecked').hide();
                    $('#COMOOtherRemarks').prop('required', false);
                }
            }).trigger('change');
            
            $('#comCheck1').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#comCheck2').prop({'disabled': true, 'checked': false});
                    $('#comCheck3').prop({'disabled': true, 'checked': false});
                    $('#comCheck4').prop({'disabled': true, 'checked': false});
                    $('#comCheck5').prop({'disabled': true, 'checked': false});
                    $('#comCheck6').prop({'disabled': true, 'checked': false});
                    $('#comCheck7').prop({'disabled': true, 'checked': false});
                    $('#comCheck8').prop({'disabled': true, 'checked': false});
                    $('#comCheck9').prop({'disabled': true, 'checked': false});
                    $('#comCheck10').prop({'disabled': true, 'checked': false});
                }
                else {
                    $('#comCheck2').prop({'disabled': false, 'checked': false});
                    $('#comCheck3').prop({'disabled': false, 'checked': false});
                    $('#comCheck4').prop({'disabled': false, 'checked': false});
                    $('#comCheck5').prop({'disabled': false, 'checked': false});
                    $('#comCheck6').prop({'disabled': false, 'checked': false});
                    $('#comCheck7').prop({'disabled': false, 'checked': false});
                    $('#comCheck8').prop({'disabled': false, 'checked': false});
                    $('#comCheck9').prop({'disabled': false, 'checked': false});
                    $('#comCheck10').prop({'disabled': false, 'checked': false});
                }
            });

            <?php if(is_null(old('comCheck', explode(",", $records->COMO)))): ?>
                $('#comCheck1').prop('checked', true);
            <?php endif; ?>

            $('#rec_ispregnant').val("N/A");
            $('#PregnantLMP').prop({disabled: true, required: false});
            $('#highRiskPregnancy').prop({disabled: true, required: false});

            $('#imagingDone').change(function (e) { 
                e.preventDefault();
                $('#divImagingOthers').hide();
                $('#imagingOtherFindings').val("");
                if($(this).val() == "None") {
                    $('#imagingDoneDate').prop({disabled: true, required: false});
                    $('#imagingResult').prop({disabled: true, required: false});
                    $("#imagingResult").empty();
                }
                else {
                    $('#imagingDoneDate').prop({disabled: false, required: true});
                    $('#imagingResult').prop({disabled: false, required: true});
                    $("#imagingResult").empty();
                    $("#imagingResult").append(new Option("Normal", "NORMAL"));
                    $("#imagingResult").append(new Option("Pending", "PENDING"));

                    $('#divImagingOthers').hide();

                    if($(this).val() == "Chest Radiography") {
                        $("#imagingResult").append(new Option("Hazy opacities, often rounded in morphology, with peripheral and lower lung dist.", "HAZY"));
                    }
                    else if($(this).val() == "Chest CT") {
                        $("#imagingResult").append(new Option("Multiple bilateral ground glass opacities, often rounded in morphology, w/ peripheral and lower lung dist.", "MULTIPLE"));
                    }
                    else if($(this).val() == "Lung Ultrasound") {
                        $("#imagingResult").append(new Option("Thickened pleural lines, B lines, consolidative patterns with or without air bronchograms.", "THICKENED"));
                    }
                    
                    if($(this).val() != "OTHERS") {
                        $("#imagingResult").append(new Option("Other findings", "OTHERS"));
                    }
                }
            }).trigger('change');

            if($('#imagingDone').val() != "N/A") {
                $('#imagingResult option[value="<?php echo e($records->imagingResult); ?>"]').prop('selected', true);
            }
            
            $('#imagingResult').change(function (e) { 
                e.preventDefault();
                $('#imagingOtherFindings').val("");
                if($(this).val() == "OTHERS") {
                    $('#divImagingOthers').show();
                    $('imagingOtherFindings').prop({disabled: false, required: true});
                }
                else {
                    $('#divImagingOthers').hide();
                    $('imagingOtherFindings').prop({disabled: true, required: false});
                }
            }).trigger('change');

            $('#testType1').change(function (e) { 
                e.preventDefault();
                if($(this).val() == 'Others') {
                    $('#divTypeOthers1').show();
                    $('#testTypeOtherRemarks1').prop('required', true);
                }
                else {
                    $('#divTypeOthers1').hide();
                    $('#testTypeOtherRemarks1').empty();
                    $('#testTypeOtherRemarks1').prop('required', false);
                }
            }).trigger('change');

            $('#testResult1').change(function (e) { 
                e.preventDefault();
                if($(this).val() == "OTHERS") {
                    $('#divResultOthers1').show();
                    $('#testResultOtherRemarks1').prop('required', true);
                }
                else {
                    $('#divResultOthers1').hide();
                    $('#testResultOtherRemarks1').empty();
                    $('#testResultOtherRemarks1').prop('required', false);
                }
            }).trigger('change');

            $('#testType2').change(function (e) { 
                e.preventDefault();
                if($(this).val() == 'Others') {
                    $('#divTypeOthers2').show();
                    $('#testTypeOtherRemarks2').prop('required', true);
                }
                else {
                    $('#divTypeOthers2').hide();
                    $('#testTypeOtherRemarks2').empty();
                    $('#testTypeOtherRemarks2').prop('required', false);
                }
            }).trigger('change');

            $('#testResult2').change(function (e) { 
                e.preventDefault();
                if($(this).val() == "OTHERS") {
                    $('#divResultOthers2').show();
                    $('#testResultOtherRemarks2').prop('required', true);
                }
                else {
                    $('#divResultOthers2').hide();
                    $('#testResultOtherRemarks2').empty();
                    $('#testResultOtherRemarks2').prop('required', false);
                }
            }).trigger('change');

            $('#testedPositiveUsingRTPCRBefore').change(function (e) { 
                e.preventDefault();
                if($(this).val() == "1") {
                    $('#divIfTestedPositiveUsingRTPCR').show();
                    $('#testedPositiveLab').prop('required', true);
                    $('#testedPositiveSpecCollectedDate').prop('required', true);
                }
                else {
                    $('#divIfTestedPositiveUsingRTPCR').hide();
                    $('#testedPositiveLab').prop('required', false);
                    $('#testedPositiveSpecCollectedDate').prop('required', false);
                }
            }).trigger('change');

            $('#outcomeCondition').change(function (e) { 
                e.preventDefault();
                if($(this).val() == 'Recovered') {
                    $('#ifOutcomeRecovered').show();
                    $('#outcomeRecovDate').prop('required', true);
                    $('#ifOutcomeDied').hide();
                    $('#outcomeDeathDate').prop('required', false);
                    $('#deathImmeCause').prop('required', false);
                    $('#deathAnteCause').prop('required', false);
                    $('#deathUndeCause').prop('required', false);
                    $('#contriCondi').prop('required', false);
                }
                else if($(this).val() == 'Died') {
                    $('#ifOutcomeRecovered').hide();
                    $('#outcomeRecovDate').prop('required', false);
                    $('#ifOutcomeDied').show();
                    $('#outcomeDeathDate').prop('required', true);
                    $('#deathImmeCause').prop('required', true);
                    $('#deathAnteCause').prop('required', true);
                    $('#deathUndeCause').prop('required', true);
                    $('#contriCondi').prop('required', true);
                }
                else {
                    $('#ifOutcomeRecovered').hide();
                    $('#outcomeRecovDate').prop('required', false);
                    $('#ifOutcomeDied').hide();
                    $('#outcomeDeathDate').prop('required', false);
                    $('#deathImmeCause').prop('required', false);
                    $('#deathAnteCause').prop('required', false);
                    $('#deathUndeCause').prop('required', false);
                    $('#contriCondi').prop('required', false);
                }
            }).trigger('change');

            $('#expoitem1').change(function (e) { 
                e.preventDefault();
                if($(this).val() == "1") {
                    $('#divExpoitem1').show();
                    $('#expoDateLastCont').prop('required', true);
                }
                else {
                    $('#divExpoitem1').hide();
                    $('#expoDateLastCont').prop('required', false);
                }
            }).trigger('change');

            $('#expoitem2').change(function (e) { 
                e.preventDefault();
                if($(this).val() == 0 || $(this).val() == 3) {
                    $('#divTravelInt').hide();
                    $('#divTravelLoc').hide();
                }
                else if($(this).val() == 1) {
                    $('#divTravelInt').hide();

                    $('#intCountry').prop('required', false);
                    $('#intDateFrom').prop('required', false);
                    $('#intDateTo').prop('required', false);
                    $('#intWithOngoingCovid').prop('required', false);
                    $('#intVessel').prop('required', false);
                    $('#intVesselNo').prop('required', false);
                    $('#intDateDepart').prop('required', false);
                    $('#intDateArrive').prop('required', false);
                    
                    $('#divTravelLoc').show();
                }
                else if($(this).val() == 2) {
                    $('#divTravelInt').show();

                    $('#intCountry').prop('required', true);
                    $('#intDateFrom').prop('required', false);
                    $('#intDateTo').prop('required', false);
                    $('#intWithOngoingCovid').prop('required', false);
                    $('#intVessel').prop('required', false);
                    $('#intVesselNo').prop('required', false);
                    $('#intDateDepart').prop('required', false);
                    $('#intDateArrive').prop('required', false);

                    $('#divTravelLoc').hide();
                }
            }).trigger('change');

            $('#placevisited1').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal1').show();

                    $('#locName1').prop('required', true);
                    $('#locAddress1').prop('required', true);
                    $('#locDateFrom1').prop('required', true);
                    $('#locDateTo1').prop('required', true);
                    $('#locWithOngoingCovid1').prop('required', true);
                }
                else {
                    $('#divLocal1').hide();

                    $('#locName1').prop('required', false);
                    $('#locAddress1').prop('required', false);
                    $('#locDateFrom1').prop('required', false);
                    $('#locDateTo1').prop('required', false);
                    $('#locWithOngoingCovid1').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited2').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal2').show();

                    $('#locName2').prop('required', true);
                    $('#locAddress2').prop('required', true);
                    $('#locDateFrom2').prop('required', true);
                    $('#locDateTo2').prop('required', true);
                    $('#locWithOngoingCovid2').prop('required', true);
                }
                else {
                    $('#divLocal2').hide();

                    $('#locName2').prop('required', false);
                    $('#locAddress2').prop('required', false);
                    $('#locDateFrom2').prop('required', false);
                    $('#locDateTo2').prop('required', false);
                    $('#locWithOngoingCovid2').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited3').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal3').show();

                    $('#locName3').prop('required', true);
                    $('#locAddress3').prop('required', true);
                    $('#locDateFrom3').prop('required', true);
                    $('#locDateTo3').prop('required', true);
                    $('#locWithOngoingCovid3').prop('required', true);
                }
                else {
                    $('#divLocal3').hide();

                    $('#locName3').prop('required', false);
                    $('#locAddress3').prop('required', false);
                    $('#locDateFrom3').prop('required', false);
                    $('#locDateTo3').prop('required', false);
                    $('#locWithOngoingCovid3').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited4').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal4').show();

                    $('#locName4').prop('required', true);
                    $('#locAddress4').prop('required', true);
                    $('#locDateFrom4').prop('required', true);
                    $('#locDateTo4').prop('required', true);
                    $('#locWithOngoingCovid4').prop('required', true);
                }
                else {
                    $('#divLocal4').hide();

                    $('#locName4').prop('required', false);
                    $('#locAddress4').prop('required', false);
                    $('#locDateFrom4').prop('required', false);
                    $('#locDateTo4').prop('required', false);
                    $('#locWithOngoingCovid4').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited5').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal5').show();

                    $('#locName5').prop('required', true);
                    $('#locAddress5').prop('required', true);
                    $('#locDateFrom5').prop('required', true);
                    $('#locDateTo5').prop('required', true);
                    $('#locWithOngoingCovid5').prop('required', true);
                }
                else {
                    $('#divLocal5').hide();

                    $('#locName5').prop('required', false);
                    $('#locAddress5').prop('required', false);
                    $('#locDateFrom5').prop('required', false);
                    $('#locDateTo5').prop('required', false);
                    $('#locWithOngoingCovid5').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited6').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal6').show();

                    $('#locName6').prop('required', true);
                    $('#locAddress6').prop('required', true);
                    $('#locDateFrom6').prop('required', true);
                    $('#locDateTo6').prop('required', true);
                    $('#locWithOngoingCovid6').prop('required', true);
                }
                else {
                    $('#divLocal6').hide();

                    $('#locName6').prop('required', false);
                    $('#locAddress6').prop('required', false);
                    $('#locDateFrom6').prop('required', false);
                    $('#locDateTo6').prop('required', false);
                    $('#locWithOngoingCovid6').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited7').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal7').show();

                    $('#locName7').prop('required', true);
                    $('#locAddress7').prop('required', true);
                    $('#locDateFrom7').prop('required', true);
                    $('#locDateTo7').prop('required', true);
                    $('#locWithOngoingCovid7').prop('required', true);
                }
                else {
                    $('#divLocal7').hide();

                    $('#locName7').prop('required', false);
                    $('#locAddress7').prop('required', false);
                    $('#locDateFrom7').prop('required', false);
                    $('#locDateTo7').prop('required', false);
                    $('#locWithOngoingCovid7').prop('required', false);
                }
            }).trigger('change');

            $('#placevisited8').change(function (e) { 
                e.preventDefault();
                if($(this).prop('checked') == true) {
                    $('#divLocal8').show();

                    //baguhin kapag kailangan kapag naka-check
                    $('#localVessel1').prop('required', false);
                    $('#localVesselNo1').prop('required', false);
                    $('#localOrigin1').prop('required', false);
                    $('#localDateDepart1').prop('required', false);
                    $('#localDest1').prop('required', false);
                    $('#localDateArrive1').prop('required', false);

                    $('#localVessel2').prop('required', false);
                    $('#localVesselNo2').prop('required', false);
                    $('#localOrigin2').prop('required', false);
                    $('#localDateDepart2').prop('required', false);
                    $('#localDest2').prop('required', false);
                    $('#localDateArrive2').prop('required', false);
                }
                else {
                    $('#divLocal8').hide();

                    $('#localVessel1').prop('required', false);
                    $('#localVesselNo1').prop('required', false);
                    $('#localOrigin1').prop('required', false);
                    $('#localDateDepart1').prop('required', false);
                    $('#localDest1').prop('required', false);
                    $('#localDateArrive1').prop('required', false);

                    $('#localVessel2').prop('required', false);
                    $('#localVesselNo2').prop('required', false);
                    $('#localOrigin2').prop('required', false);
                    $('#localDateDepart2').prop('required', false);
                    $('#localDest2').prop('required', false);
                    $('#localDateArrive2').prop('required', false);

                    $('localVessel1').val("");
                    $('localVesselNo1').val("");
                    $('localOrigin1').val("");
                    $('localDateDepart1').val("");
                    $('localDest1').val("");
                    $('localDateArrive1').val("");

                    $('localVessel2').val("");
                    $('localVesselNo2').val("");
                    $('localOrigin2').val("");
                    $('localDateDepart2').val("");
                    $('localDest2').val("");
                    $('localDateArrive2').val("");
                }
            }).trigger('change');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cesu\resources\views/formsedit.blade.php ENDPATH**/ ?>