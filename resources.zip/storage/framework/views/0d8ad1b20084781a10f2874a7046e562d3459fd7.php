

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <div>
                CIF List
                </div>
                <div>
                    <?php if($records > 0): ?>
                        <a href="<?php echo e(route('forms.create')); ?>" class="btn btn-success">New CIF</a>
                    <?php else: ?>
                    <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="Create patient record first to process CIF.">
                        <button class="btn btn-success" style="pointer-events: none;" type="button" disabled>New CIF</button>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-<?php echo e(session('statustype')); ?>" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            
            <form action="<?php echo e(route('forms.index')); ?>" method="GET">
                <div class="input-group mb-3">
                    <select class="form-control" name="view" id="">
                        <option value="1" <?php echo e((request()->get('view') == '1') ? 'selected' : ''); ?>>Show All</option>
                        <option value="2" <?php echo e((request()->get('view') == '2') ? 'selected' : ''); ?>>Show All Except Records that has less than 5 Days Exposure History from this day</option>
                        <option value="3" <?php echo e((request()->get('view') == '3') ? 'selected' : ''); ?>>Show All Except Records that has not been exported to Excel yet</option>
                    </select>
                    <div class="input-group-append">
                      <button class="btn btn-outline-info" type="submit"><i class="fas fa-filter mr-2"></i>Filter</button>
                    </div>
                </div>
            </form>

            <form action="<?php echo e(route('forms.export')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm" id="table_id">
                        <thead>
                            <tr>
                                <th colspan="18" class="text-right"><button type="submit" class="btn btn-primary my-2" id="submit">Export to Excel</button></th>
                            </tr>
                            <tr class="text-center">
                                <th style="vertical-align: middle;"><input type="checkbox" class="checks mx-2" name="" id="select_all"></th>
                                <th style="vertical-align: middle;">Name</th>
                                <th style="vertical-align: middle;">Philhealth</th>
                                <th style="vertical-align: middle;">Birthdate</th>
                                <th style="vertical-align: middle;">Age/Gender</th>
                                <th style="vertical-align: middle;">Brgy</th>
                                <th style="vertical-align: middle;">City</th>
                                <th style="vertical-align: middle;">Type of Client</th>
                                <th style="vertical-align: middle;">Has Exposure History</th>
                                <th style="vertical-align: middle;">Date of Last Contact</th>
                                <th style="vertical-align: middle;">Date of Collection</th>
                                <th style="vertical-align: middle;">Test Type</th>
                                <th style="vertical-align: middle;">Status</th>
                                <th style="vertical-align: middle;">Encoded By</th>
                                <th style="vertical-align: middle;">Encoded At</th>
                                <th style="vertical-align: middle;">Printed?</th>
                                <th style="vertical-align: middle;">Date Printed</th>
                                <th style="vertical-align: middle;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($form->user->brgy_id == auth()->user()->brgy_id || is_null(auth()->user()->brgy_id)): ?>
                                    <?php
            
                                        if($form->expoitem1 == 1) {
                                            $emsg = "YES";
                                        }
                                        else if($form->expoitem1 == 2) {
                                            $emsg = "NO";
                                        }
                                        else {
                                            $emsg = "UNKNOWN";
                                        }
            
                                        if(is_null($form->expoDateLastCont)) {
                                            $edate = "N/A";
                                        } 
                                        else {
                                            $edate = date('m/d/Y', strtotime($form->expoDateLastCont));
                                        }
            
                                        if($form->isExported == 1) {
                                            $textcolor = 'success';
                                        }
                                        else {
                                            $textcolor = 'warning';
                                        }
                                    ?>
                                    <tr class="text-<?php echo e($textcolor); ?>">
                                        <th class="text-center" style="vertical-align: middle;">
                                            <input type="checkbox" class="checks mx-2" name="listToPrint[]" id="" value="<?php echo e($form->id); ?>">
                                        </th>
                                        <td style="vertical-align: middle;"><?php echo e($form->records->lname); ?>, <?php echo e($form->records->fname); ?> <?php echo e($form->records->mname); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e((!is_null($form->records->philhealth)) ? $form->records->philhealth : 'N/A'); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e(date('m/d/Y', strtotime($form->records->bdate))); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->records->getAge()); ?> / <?php echo e($form->records->gender); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->records->address_brgy); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->records->address_city); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->pType); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($emsg); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($edate); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->testDateCollected1); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->testType1); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e($form->testResult1); ?></td>
                                        <td style="vertical-align: middle;"><?php echo e($form->user->name); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e(date("m/d/Y h:i A", strtotime($form->created_at))); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e(($form->isExported == 1) ? 'YES' : 'NO'); ?></td>
                                        <td style="vertical-align: middle;" class="text-center"><?php echo e((!is_null($form->exportedDate)) ? date('m/d/Y h:i A', strtotime($form->exportedDate)) : ''); ?></td>
                                        <td style="vertical-align: middle;" class="text-center">
                                            <a href="forms/<?php echo e($form->id); ?>/edit" class="btn btn-primary btn-sm">Edit</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })

    $(document).ready(function () {
        $('#table_id').DataTable();

        $('#select_all').change(function() {
        var checkboxes = $(this).closest('form').find(':checkbox');
        checkboxes.prop('checked', $(this).is(':checked'));
        });
    });

    $('#submit').prop('disabled', true);

    $('input:checkbox').click(function() {
        if ($(this).is(':checked')) {
            $('#submit').prop("disabled", false);
        } else {
        if ($('.checks').filter(':checked').length < 1){
            $('#submit').attr('disabled',true);}
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cesu\resources\views/forms.blade.php ENDPATH**/ ?>