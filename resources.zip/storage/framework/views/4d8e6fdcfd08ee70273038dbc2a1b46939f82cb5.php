

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <div>
                    Line List
                </div>
                <div>
                    <a href="<?php echo e(route('linelist.createoni')); ?>" class="btn btn-success">Create ONI</a>
                </div>
            </div>
        </div>
        <div class="card-body">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cesu\resources\views/linelist_index.blade.php ENDPATH**/ ?>