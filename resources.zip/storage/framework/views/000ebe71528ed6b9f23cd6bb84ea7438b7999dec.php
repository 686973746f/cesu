

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Welcome: <?php echo e(strtoupper(auth()->user()->name)); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('records.index')); ?>" class="btn btn-primary btn-lg btn-block"><i class="fa fa-user mr-2" aria-hidden="true"></i>Patient Information</a>
                    <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-primary btn-lg btn-block"><i class="fa fa-file mr-2" aria-hidden="true"></i>View/Create CIF</a>
                    <a href="<?php echo e(route('linelist.index')); ?>" class="btn btn-primary btn-lg btn-block">Line List</a>
                    <hr>
                    <a href="" class="btn btn-primary btn-lg btn-block"><i class="fas fa-chart-bar mr-2"></i>Reports</a>
                    <?php if(auth()->user()->isAdmin == 1): ?>
                        <hr>
                        <a href="<?php echo e(route('adminpanel.index')); ?>" class="btn btn-primary btn-lg btn-block">Admin Panel</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cesu\resources\views/home.blade.php ENDPATH**/ ?>